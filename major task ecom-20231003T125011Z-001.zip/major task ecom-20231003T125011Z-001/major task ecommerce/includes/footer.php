<footer class="footer">
    <div class="container text-center"><span class="text-muted"><b>Copyright&copy; All Rights Reserved 2023 | Developer : Deeksha Agarwal /Contact Us: +917229841500</b></span></div>
</footer>
    